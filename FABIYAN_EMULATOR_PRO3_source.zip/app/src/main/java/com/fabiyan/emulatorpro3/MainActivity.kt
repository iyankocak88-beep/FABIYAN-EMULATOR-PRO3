package com.fabiyan.emulatorpro3

import android.app.Activity
import android.os.Bundle
import android.hardware.input.InputManager
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.content.Context

class MainActivity : Activity(), InputManager.InputDeviceListener {
    private lateinit var inputManager: InputManager
    private lateinit var statusText: TextView
    private lateinit var devicesText: TextView
    private lateinit var eventText: TextView
    private lateinit var profileText: TextView
    private var profile = "Default"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        inputManager = getSystemService(Context.INPUT_SERVICE) as InputManager
        inputManager.registerInputDeviceListener(this, null)
        buildScreen()
        refreshDevices()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 24)
            setBackgroundColor(Color.rgb(9, 9, 9))
        }
        fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
            return TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                if (bold) setTypeface(null, Typeface.BOLD)
                setPadding(0, 10, 0, 10)
            }
        }
        val gold = Color.rgb(226, 178, 55)
        root.addView(text("FABIYAN", 15f, gold, true))
        root.addView(text("EMULATOR PRO3", 27f, Color.WHITE, true))
        root.addView(text("USB OTG  •  BLUETOOTH", 12f, gold, true))
        statusText = text("Memeriksa perangkat...", 16f, Color.WHITE, true)
        root.addView(statusText)
        root.addView(text("PERANGKAT TERDETEKSI", 13f, gold, true))
        devicesText = text("Belum ada perangkat eksternal.", 14f, Color.LTGRAY)
        root.addView(devicesText)
        root.addView(text("PROFIL KONTROL", 13f, gold, true))
        profileText = text("Profil aktif: $profile", 15f, Color.WHITE)
        root.addView(profileText)
        val profiles = listOf("Default", "FPS", "MOBA")
        profiles.forEach { name ->
            val button = TextView(this).apply {
                text = "  $name  "
                textSize = 14f
                setTextColor(Color.BLACK)
                setTypeface(null, Typeface.BOLD)
                setBackgroundColor(gold)
                gravity = Gravity.CENTER
                setPadding(14, 13, 14, 13)
                setOnClickListener {
                    profile = name
                    profileText.text = "Profil aktif: $profile"
                }
            }
            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(0, 5, 0, 5)
            root.addView(button, params)
        }
        root.addView(text("UJI INPUT", 13f, gold, true))
        eventText = text("Gerakkan mouse atau tekan tombol keyboard saat aplikasi terbuka.", 13f, Color.LTGRAY)
        root.addView(eventText)
        root.addView(text(
            "Catatan: versi awal mendeteksi perangkat HID dan input di aplikasi. " +
            "Pemetaan menjadi sentuhan di game lain memerlukan implementasi layanan/izin Android tambahan.",
            11f, Color.GRAY
        ))
        setContentView(root)
    }

    private fun refreshDevices() {
        val ids = inputManager.inputDeviceIds
        val lines = mutableListOf<String>()
        var mouseCount = 0
        var keyboardCount = 0
        for (id in ids) {
            val device = inputManager.getInputDevice(id) ?: continue
            if (device.isVirtual) continue
            val sources = device.sources
            val isMouse = (sources and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE ||
                (sources and InputDevice.SOURCE_MOUSE_RELATIVE) == InputDevice.SOURCE_MOUSE_RELATIVE
            val isKeyboard = device.keyboardType != InputDevice.KEYBOARD_TYPE_NONE
            if (isMouse || isKeyboard) {
                val kinds = mutableListOf<String>()
                if (isMouse) { kinds.add("Mouse"); mouseCount++ }
                if (isKeyboard) { kinds.add("Keyboard"); keyboardCount++ }
                lines.add("• ${device.name} — ${kinds.joinToString(" + ")}")
            }
        }
        devicesText.text = if (lines.isEmpty()) "Belum ada mouse/keyboard terdeteksi." else lines.joinToString("\n")
        statusText.text = if (lines.isEmpty()) "STATUS: MENUNGGU PERANGKAT" else "STATUS: PERANGKAT TERHUBUNG"
    }

    override fun onInputDeviceAdded(deviceId: Int) = refreshDevices()
    override fun onInputDeviceRemoved(deviceId: Int) = refreshDevices()
    override fun onInputDeviceChanged(deviceId: Int) = refreshDevices()

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (::eventText.isInitialized && event.action == KeyEvent.ACTION_DOWN) {
            eventText.text = "Keyboard terdeteksi: ${KeyEvent.keyCodeToString(event.keyCode)}"
        }
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (::eventText.isInitialized && event.source and InputDevice.SOURCE_MOUSE == InputDevice.SOURCE_MOUSE) {
            eventText.text = "Input mouse terdeteksi • X: ${event.x.toInt()} • Y: ${event.y.toInt()}"
        }
        return super.dispatchGenericMotionEvent(event)
    }

    override fun onDestroy() {
        inputManager.unregisterInputDeviceListener(this)
        super.onDestroy()
    }
}
