# FABIYAN EMULATOR PRO3 — Starter Android Project

Versi awal ini menyediakan:
- Dashboard hitam/emas.
- Deteksi perangkat input fisik yang dikenali Android (mouse/keyboard USB OTG atau Bluetooth HID).
- Profil UI sederhana: Default, FPS, MOBA.
- Uji input dasar saat aplikasi sedang terbuka.

## Batasan penting
Ini belum mengubah gerakan mouse/tekanan tombol menjadi sentuhan di game lain. Android membatasi injeksi input lintas aplikasi. Fitur tersebut perlu rancangan layanan Android yang sesuai, izin pengguna, serta pengujian kompatibilitas; beberapa game juga dapat melarang alat pemetaan input pihak ketiga.

## Build APK
1. Buka folder proyek ini di Android Studio pada komputer.
2. Tunggu Gradle Sync selesai.
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

Persyaratan: Android Studio dengan Android SDK 35 dan JDK 17.
